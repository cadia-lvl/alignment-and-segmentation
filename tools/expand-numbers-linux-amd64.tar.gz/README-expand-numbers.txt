Kaldi was compiled with CXX=g++-7 ./configure --mathlib=OPENBLAS  --cudatk-dir=/usr/local/cuda-10.0 --static --static-math --static-fst to create this binary
glibc on the machine is 2.28
To get a version of expand-numbers where the glibc version is 2.29 extract expand-numbers from here: http://kjaran.com/dist/expand-numbers-linux-amd64.zip
